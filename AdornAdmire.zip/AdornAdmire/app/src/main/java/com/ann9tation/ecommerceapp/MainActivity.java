package com.ann9tation.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ann9tation.ecommerceapp.adapter.ProductAdapter;
import com.ann9tation.ecommerceapp.adapter.ProductCategoryAdapter;
import com.ann9tation.ecommerceapp.model.ProductCategory;
import com.ann9tation.ecommerceapp.model.Products;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ProductCategoryAdapter adapter;
    RecyclerView recyclerView,productItemRecycler;
    ProductAdapter productAdapter;

    private TextView tv_hair,tv_face,tv_body,tv_skin;
    private Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<ProductCategory> productCategoryList=new ArrayList<>();
        productCategoryList.add(new ProductCategory(1,"Most Popular"));
        productCategoryList.add(new ProductCategory(2,"All Body Products"));
        productCategoryList.add(new ProductCategory(3,"Skin Care"));
        productCategoryList.add(new ProductCategory(4,"Hair"));
        setRecyclerView(productCategoryList);

        List<Products> productsList=new ArrayList<>();
        productsList.add(new Products(1,"Japanese Cherry Blossom","250 mL","₹ 500",R.drawable.prod2));
        productsList.add(new Products(2,"African Shower Mango Gel","350 mL","₹ 850",R.drawable.prod1));
        productsList.add(new Products(3,"Japanese Cherry Blossom","250 mL","₹ 500",R.drawable.prod2));
        productsList.add(new Products(2,"African Shower Mango Gel","350 mL","₹ 850",R.drawable.prod1));
        productsList.add(new Products(3,"Japanese Cherry Blossom","250 mL","₹ 500",R.drawable.prod2));
        setproductRecyclerView(productsList);

        initViews();
        initListners();

    }

    private void initListners() {
        tv_hair.setOnClickListener(this);
        tv_face.setOnClickListener(this);
        tv_body.setOnClickListener(this);
        tv_skin.setOnClickListener(this);
    }

    private void initViews() {
        tv_skin=findViewById(R.id.tv_skin);
        tv_hair=findViewById(R.id.tv_hair);
        tv_face=findViewById(R.id.tv_face);
        tv_body=findViewById(R.id.tv_body);
        btn=findViewById(R.id.button);
    }


    private void setRecyclerView(List<ProductCategory> productCategoryList){
        recyclerView=findViewById(R.id.cat_recycler);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new ProductCategoryAdapter(this,productCategoryList);
        recyclerView.setAdapter(adapter);
    }

    private void setproductRecyclerView(List<Products> productslist){
        productItemRecycler=findViewById(R.id.product_recycler);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false);
        productItemRecycler.setLayoutManager(layoutManager);
        productAdapter=new ProductAdapter(this,productslist);
        productItemRecycler.setAdapter(productAdapter);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.tv_body:
                break;
            case R.id.tv_face:
                break;
            case R.id.tv_hair:
                break;
            case R.id.tv_skin:
                break;

        }
    }
}