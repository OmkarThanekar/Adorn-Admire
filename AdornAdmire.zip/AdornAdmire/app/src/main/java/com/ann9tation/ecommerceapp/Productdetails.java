package com.ann9tation.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Productdetails extends AppCompatActivity implements View.OnClickListener {
    private TextView tv_qty;
    private ImageView ic_plus,ic_minus,ic_back;
    private Button btn_cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productdetails);
        initViews();
        initListners();
    }

    private void initListners() {
        ic_minus.setOnClickListener(this);
        ic_plus.setOnClickListener(this);
        btn_cart.setOnClickListener(this);
        ic_back.setOnClickListener(this);
    }

    private void initViews() {
        tv_qty=findViewById(R.id.tv_qty);
        ic_plus=findViewById(R.id.plus);
        ic_minus=findViewById(R.id.minus);
        ic_back=findViewById(R.id.back);
        btn_cart=findViewById(R.id.btn_add_cart);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn_add_cart:
                Toast.makeText(this, tv_qty.getText().toString()+" units added to cart Successfully.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.plus:
                tv_qty.setText(Integer.toString(Integer.parseInt(tv_qty.getText().toString())+1));
                break;
            case R.id.minus:
                if (Integer.parseInt(tv_qty.getText().toString())>1)
                    tv_qty.setText(Integer.toString(Integer.parseInt(tv_qty.getText().toString())-1));
                else
                    Toast.makeText(this, "Minimum Quantity should be 1.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.back:
                onBackPressed();
                break;
        }

    }
}